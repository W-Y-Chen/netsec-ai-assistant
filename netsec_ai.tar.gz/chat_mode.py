from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

print("Loading Qwen2.5-7B...")
model_name = "Qwen/Qwen2.5-7B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True
)
print("Model loaded! 输入 'exit' 退出\n")

while True:
    user_input = input("你: ")
    if user_input.lower() in ['exit', 'quit', 'q']:
        print("再见!")
        break
    
    messages = [
        {"role": "system", "content": "You are a cybersecurity expert. Help with penetration testing, code audit, and vulnerability analysis."},
        {"role": "user", "content": user_input}
    ]
    
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer([text], return_tensors="pt").to(model.device)
    
    print("AI: ", end="", flush=True)
    outputs = model.generate(**inputs, max_new_tokens=1024, do_sample=True, temperature=0.7)
    response = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]
    
    if "assistant" in response:
        response = response.split("assistant")[-1].strip()
    
    print(response)
    print()
